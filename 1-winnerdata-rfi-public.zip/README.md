# WinnerData Request for Information

MIT-licensed static HTML intake tracker. Public template only: never commit real client records, documents, private links or secrets.

## Status semantics

- Information needed: not received.
- Received: a source has arrived; reviewer checks are still pending.
- Not yet verified: current evidence or account state has not been checked.
- Decision needed: an owner or legal reviewer must make a decision.
- Verified: the agreed completion test passed.

Completion is verified items divided by the current agreed checklist, not a claim that all future requirements are known. Display the checklist version and date. Receipt alone never raises verified completion.

## Security

This template has no upload endpoint, input fields, localStorage or document persistence. Filing is disabled until a real private backend is configured and tested. The notice is guidance, not an access control.

Put every real client deployment behind server-side authentication before adding any client data. Protect every deployment alias, API, object and custom-domain route. Never rely on noindex, obscure IDs or JavaScript passwords. Keep client state outside the public repository. Use an explicit per-client allowlist and storage authorization. Do not grant one client's users access to another client. Do not reuse a shared admin group without checking its audience.

Passwords, API keys, card data and other persistent secrets must go through a recipient-scoped credential vault request. Do not collect them in HTML, browser storage, GitHub issues or uploaded documents.

For private documents require authenticated upload/download, client-scoped server-side authorization, private object storage, file type/size limits, malware handling, retention/deletion policy and an audit trail. Do not enable the filing button based on an untested endpoint.

## Cloudflare deployment

The example can be deployed as static assets on an existing Cloudflare Pages project. For a real client: deploy generic assets first, establish Access on the primary hostname AND all deployment aliases, verify unauthenticated requests are denied, then add private data. A Pages zip upload does not add a secure backend. Test the exact intended client identity and a different client identity before onboarding.

## Review

Check 390px and 1440px layouts, all filters, empty states and expanded completion rules. Security tests must cover unauthenticated HTML/data/assets/API/object access, identity expiry, wrong-client requests and public aliases. A screenshot cannot prove authentication or upload isolation.
